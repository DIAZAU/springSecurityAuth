OpenClassrooms Course 'Sécurisez votre application web avec Spring Security' - Official GitHub repository
